<div align="center">
<a href="https://www.youtube.com/watch?v=KqgyScOlvV8"><img src="https://i.ibb.co/Mfkw6xT/eternity-5.png" alt="2258810" border="0" /></a>

# **NEZUKO : MULTI DEVICE WHATSAPP BOT WITH COOL FEATURES**

</p>
<p align="center">
<a href="https://github.com/pratyush4932"><img title="Author" src="https://img.shields.io/badge/Author-Pratyush-red.svg?style=for-the-badge&logo=github"></a>
</p>
 <a href="https://github.com/EternityBots/Nezuko/blob/main/LICENSE">
  
<img src='https://img.shields.io/github/license/EternityBots/Nezuko?color=%231e81b0&style=for-the-badge'>

<p align="center">
<a href="https://github.com/pratyush4932"><img title="Open Source" src="https://img.shields.io/badge/Open%20Source-%E2%99%A5%EF%B8%8F-blue.svg?style=for-the-badge"></a>
<a href="https://github.com/is7s7whs"><img title="" src="https://img.shields.io/badge/Maintained-YES-green.svg?style=for-the-badge"></a>
</p>

---

## 📚 Information 📚

> A simple and easy-to-use WhatsApp bot project with cool Features based on Multi-Device Baileys and written in JavaScript.

## 💖 NEZUKO 💖

> This is a open source project by the TEAM ETERNITY. After forking If you change any codes and claim That's yours then Our Team will Take Action In that case so be careful and give Credit To The original Devloper of that Bot. if you Have any Questions Then Join Our support Group To Report Your Issues.

[![WhatsApp Group](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/JCCZPbPUbM1536n62zSFZi)

## 💡 License

Nezuko is free and open-source software licensed under the [GNU Affero General Public License v3.0](https://github.com/EternityBots/Nezuko/blob/main/LICENSE).

## RAILWAY

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template/xhqo2N?referralCode=QaaU0X)

## KOYEB

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/apps/deploy?type=docker&image=quay.io/raysenpai69/nezuko:main&env[PORT]=8000&env[PREFIX]&&env[MONGODB]&&env[SESSION_ID]=NEZUKO&env[WEATHER_API]&&env[GOOGLE_API]&&env[MODS]&&env[MAL_USERNAME]=PratyushOP&env[MAL_PASSWORD]=8scv98gxDYHVBry&name=nezuko)

## Clone this project

```bash
> git clone https://github.com/Eternity-Bots/Nezuko
```

## Installation:

> Before running the below command, make sure you're in the project directory that
> you've just cloned!!

```bash
  > yarn install
> yarn start

To keep it on forever
 > node kyoeb.js
```

## HELP

> Please give this repo a ⭐ if you liked it.

# ✨ Creator ✨

<a href="https://github.com/pratyush4932"><img src="https://github.com/pratyush4932.png?size=100" width="100" height="100"></a>

[Pratyush](https://github.com/pratyush4932)
| Creator |

# Modifiers

| <a href="https://github.com/Eximinati"><img src="https://github.com/Eximinati.png?size=100" width="100" height="100"></a> | [![Ray_Senpai](https://github.com/RaySenpai69.png?size=100)](https://github.com/RaySenpai69) |
| ------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| [Aku](https://github.com/Eximinati)                                                                                       | [Ray_Senpai](https://github.com/RaySenpai69)                                                 |
| Modifier                                                                                                                  | Modifier                                                                                     |

# Contributor 🤝🏻

| <a href="https://github.com/Toshi-san001"><img src="https://github.com/Toshi-san001.png?size=100" width="100" height="100"></a> | [![Arin](https://github.com/Arin1601.png?size=100)](https://github.com/Arin1601)               |
| ------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| [Toshi_Sama](https://github.com/Toshi-san001)                                                                                   | [Arin](https://github.com/Arin1601)                                                            |
| Useless Worker                                                                                                                  | Contributor                                                                                    |
| <a href="https://github.com/Debanjan-San"><img src="https://github.com/Debanjan-San.png?size=100" width="100" height="100"></a> | [![Alι_Aryαɴ](https://github.com/AliAryanTech.png?size=100)](https://github.com/AliAryanTech)  |
| [Debanjan-San](https://github.com/Debanjan-San)                                                                                 | [Alι_Aryαɴ](https://github.com/AliAryanTech)                                                   |
| Contributor                                                                                                                     | Contributor                                                                                    |
| <a href="https://github.com/FantoX001"><img src="https://github.com/FantoX001.png?size=100" width="100" height="100"></a>       | [![Well/300>](https://github.com/well300.png?size=100)](https://github.com/well300)            |
| [Fantox](https://github.com/FanotX001)                                                                                          | [Well300>](https://github.com/well300)                                                         |
| Contributor                                                                                                                     | Contributor                                                                                    |
| <a href="https://github.com/Chey-san"><img src="https://github.com/Chey-san.png?size=100" width="100" height="100"></a>         | [![SaruMan_sama](https://github.com/SarumanSama.png?size=100)](https://github.com/SarumanSama) |
| [Chey_San](https://github.com/Chey-san)                                                                                         | [SaruMan](https://github.com/SarumanSama)                                                      |
| Contributor                                                                                                                     | Contributor                                                                                    |
