const { serialize } = require("./wamessage")

module.exports = {
    Collection: require("./Commands"),
    Simple: require("./wamessage"),
    
}
